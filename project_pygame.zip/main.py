import pygame
import random
import os


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.board2 = [[0] * width for _ in range(height)]
        self.left = 10
        self.left2 = 480
        self.top = 10
        self.cell_size = 30
        self.sp = []
        self.sp_opponent = []
        self.count = 0
        self.sp_position = []
        self.ships_standing = False
        self.sp_shots_opponent = []
        self.sp_shots = []
        self.sp_check = []
        self.sp_check_opponent = []
        self.tile_width = 30
        self.tile_height = 30
        self.board_game_over = False
        self.board_result = 0
        self.score = 0
        self.no_score = 0
        self.score_opponent = 0
        self.no_score_opponent = 0
        self.sp_random_shot = []
        for i in range(1, 11):
            for j in range(1, 11):
                col = (i, j)
                self.sp_position.append(col)

    def render2(self, screen):
        f1 = pygame.font.Font(None, 36)
        text1 = f1.render('Твое поле', True,
                          (0, 180, 0))

        screen.blit(text1, (100, 310))
        texture = pygame.image.load('Data/water.jpg')
        screen.blit(texture, (490, 10))
        all_sprites = pygame.sprite.Group()
        sprite = pygame.sprite.Sprite()
        sprite.image = load_image("krest3.png")
        sprite.image = load_image("vzr.png")
        sprite.rect = sprite.image.get_rect()
        # all_sprites.add(sprite)
        krest_image = load_image("krest3.png")
        vzr_image = load_image("vzr.png")
        for i in range(self.width):
            for j in range(self.height):
                pygame.draw.rect(screen, pygame.Color(255, 255, 255), (480 + i * self.cell_size + self.left + 1,
                                                                       j * self.cell_size + self.top + 1,
                                                                       self.cell_size - 1, self.cell_size - 1), 1)

                if self.board2[j][i] == 1:
                    vzr = pygame.sprite.Sprite(all_sprites)
                    vzr.image = vzr_image
                    vzr.rect = vzr.image.get_rect()
                    vzr.rect.x = 480 + i * self.cell_size + self.left + 2
                    vzr.rect.y = j * self.cell_size + self.top + 2
                    all_sprites.draw(screen)
                    # pygame.draw.rect(screen, pygame.Color(0, 0, 255), (480 + i * self.cell_size + self.left + 2,
                    #                                                   j * self.cell_size + self.top + 2,
                    #                                                   self.cell_size - 2, self.cell_size - 2), 0)

        for elem in self.sp_shots:
            krest = pygame.sprite.Sprite(all_sprites)
            krest.image = krest_image
            krest.rect = krest.image.get_rect()
            krest.rect.x = 480 + elem[0] * self.cell_size + self.left + 2
            krest.rect.y = elem[1] * self.cell_size + self.top + 2
            all_sprites.draw(screen)
            # pygame.draw.line(screen, pygame.Color(255, 0, 0), (480 + elem[0] * self.cell_size + self.left + 2,
            #                                                   elem[1] * self.cell_size + self.top + 2),
            #                 (480 + elem[0] * self.cell_size + self.left + self.cell_size - 2,
            #                  elem[1] * self.cell_size + self.top + self.cell_size - 2), 3)
            # pygame.draw.line(screen, pygame.Color(255, 0, 0),
            #                 (480 + elem[0] * self.cell_size + self.left + self.cell_size - 2,
            #                  elem[1] * self.cell_size + self.top + 2),
            #                 (480 + elem[0] * self.cell_size + self.left + 2,
            #                  elem[1] * self.cell_size + self.top + self.cell_size - 2), 3)

    def render(self, screen):
        if self.ships_standing:
            f3 = pygame.font.Font(None, 36)
            text3 = f3.render('Расстановка кораблей окончена. Игра началась!', True,
                              (0, 0, 128))
            screen.blit(text3, (120, 350))

        f1 = pygame.font.Font(None, 36)
        text1 = f1.render('Поле противника', True,
                          (180, 0, 0))

        screen.blit(text1, (540, 310))
        texture = pygame.image.load('Data/water.jpg')
        screen.blit(texture, (10, 10))
        all_sprites = pygame.sprite.Group()
        sprite = pygame.sprite.Sprite()
        sprite.image = load_image("krest3.png")
        sprite.image = load_image("ship.png")
        sprite.rect = sprite.image.get_rect()
        # all_sprites.add(sprite)
        krest_image = load_image("krest3.png")
        ship_image = load_image("ship.png")
        for i in range(self.width):
            for j in range(self.height):

                pygame.draw.rect(screen, pygame.Color(0, 0, 0), (i * self.cell_size + self.left + 1,
                                                                 j * self.cell_size + self.top + 1,
                                                                 self.cell_size - 1, self.cell_size - 1), 1)
                if self.board[j][i] == 1:
                    ship = pygame.sprite.Sprite(all_sprites)
                    ship.image = ship_image
                    ship.rect = ship.image.get_rect()
                    ship.rect.x = i * self.cell_size + self.left + 1
                    ship.rect.y = j * self.cell_size + self.top + 2
                    all_sprites.draw(screen)
                    # pygame.draw.rect(screen, pygame.Color(0, 255, 0), (i * self.cell_size + self.left + 2,
                    #                                                   j * self.cell_size + self.top + 2,
                    #                                                   self.cell_size - 2, self.cell_size - 2), 0)
        for elem in self.sp_shots_opponent:
            krest = pygame.sprite.Sprite(all_sprites)
            krest.image = krest_image
            krest.rect = krest.image.get_rect()
            krest.rect.x = elem[0] * self.cell_size + self.left + 2
            krest.rect.y = elem[1] * self.cell_size + self.top + 2
            all_sprites.draw(screen)
            # pygame.draw.line(screen, pygame.Color(255, 0, 0), (elem[0] * self.cell_size + self.left + 2,
            #                                                   elem[1] * self.cell_size + self.top + 2),
            #                 (elem[0] * self.cell_size + self.left + self.cell_size - 2,
            #                  elem[1] * self.cell_size + self.top + self.cell_size - 2), 3)
            # pygame.draw.line(screen, pygame.Color(255, 0, 0),
            #                 (elem[0] * self.cell_size + self.left + self.cell_size - 2,
            #                  elem[1] * self.cell_size + self.top + 2),
            #                 (elem[0] * self.cell_size + self.left + 2,
            #                  elem[1] * self.cell_size + self.top + self.cell_size - 2), 3)

    def set_view(self, left, left2, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size
        self.left2 = left2

    def get_cell(self, coords):
        for i in range(self.width):
            for j in range(self.height):
                if (i * self.cell_size + self.left <= coords[0] <= i * self.cell_size + self.left + self.cell_size and
                        j * self.cell_size + self.top + self.top < coords[
                            1] < j * self.cell_size + self.top + self.cell_size):
                    return (i, j)
        return None

    def get_cell2(self, coords):
        for i in range(self.width):
            for j in range(self.height):
                if (i * self.cell_size + self.left2 <= coords[0] <= i * self.cell_size + self.left2 + self.cell_size and
                        j * self.cell_size + self.top + self.top < coords[
                            1] < j * self.cell_size + self.top + self.cell_size):
                    return (i, j)
        return None

    def on_click1(self, cell):
        if cell != None:
            if cell in self.sp:
                self.sp.remove(cell)
                self.count -= 1
            else:
                self.count += 1
                if self.count <= 20:
                    self.sp.append(cell)
                    self.sp_check.append(cell)
                else:
                    self.ships_standing = True
                    self.check()

            if cell and not self.ships_standing:
                self.board[cell[1]][cell[0]] = (self.board[cell[1]][cell[0]] + 1) % 2

    def on_click2(self, cell):
        if self.ships_standing:
            if cell in self.sp_opponent:
                # попал
                self.score += 1
                self.board2[cell[1]][cell[0]] = 1
                if cell in self.sp_check_opponent:
                    self.sp_check_opponent.remove(cell)
                if self.sp_check_opponent == []:
                    self.board_game_over = True
                    self.board_result = 1
            else:
                # промазал
                self.no_score += 1
                self.sp_shots.append(cell)
            true_shot = True
            while true_shot:
                shot_x = random.randint(0, 9)
                shot_y = random.randint(0, 9)
                shot = (shot_x, shot_y)
                if shot not in self.sp_random_shot:
                    self.sp_random_shot.append(shot)
                    true_shot = False
            self.sp_shots_opponent.append(shot)
            if shot in self.sp_check:
                self.sp_check.remove(shot)
                self.score_opponent += 1
            else:
                self.no_score_opponent += 1
            if self.sp_check == []:
                self.board_game_over = True
                self.board_result = 0

    def get_click(self, mouse_pos):
        cell1 = self.get_cell(mouse_pos)
        cell2 = self.get_cell2(mouse_pos)
        if cell1 == None and cell2 != None:
            self.on_click2(cell2)
        elif cell2 == None and cell1 != None:
            self.on_click1(cell1)

    def check(self):
        pass

    def ship_arrangement(self):
        direction = random.randint(0, 1)
        if direction == 0:
            pos_list_x = [0, 1, 2, 3, 4, 5]
            pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        else:
            pos_list_y = [0, 1, 2, 3, 4, 5]
            pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        position_x = random.choice(pos_list_x)
        position_y = random.choice(pos_list_y)
        for i in range(4):
            if direction == 0:
                pos = (position_x + i, position_y)
            else:
                pos = (position_x, position_y + i)
            self.sp_opponent.append(pos)
            self.del_space(direction, position_x, position_y, i)
            self.sp_check_opponent.append(pos)

        for i in range(2):
            direction = random.randint(0, 1)
            if direction == 0:
                pos_list_x = [0, 1, 2, 3, 4, 5, 6]
                pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            else:
                pos_list_y = [0, 1, 2, 3, 4, 5, 6]
                pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            position_x = random.choice(pos_list_x)
            position_y = random.choice(pos_list_y)
            pos = (position_x, position_y)
            if pos in self.sp_position:
                if direction == 0:
                    pos_1 = (position_x + 1, position_y)
                else:
                    pos_1 = (position_x, position_y + 1)
                if pos_1 in self.sp_position:
                    if direction == 0:
                        pos_2 = (position_x + 2, position_y)
                    else:
                        pos_2 = (position_x, position_y + 2)
                    if pos_2 in self.sp_position:
                        self.sp_opponent.append(pos)
                        self.sp_opponent.append(pos_1)
                        self.sp_opponent.append(pos_2)
                        self.sp_check_opponent.append(pos)
                        self.sp_check_opponent.append(pos_1)
                        self.sp_check_opponent.append(pos_2)

                        for i in range(3):
                            self.del_space(direction, position_x, position_y, i)
                    else:
                        self.ship_3()
                else:
                    self.ship_3()
            else:
                self.ship_3()

        for i in range(3):
            direction = random.randint(0, 1)
            if direction == 0:
                pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7]
                pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            else:
                pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7]
                pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            position_x = random.choice(pos_list_x)
            position_y = random.choice(pos_list_y)
            pos = (position_x, position_y)
            if pos in self.sp_position:
                if direction == 0:
                    pos_1 = (position_x + 1, position_y)
                else:
                    pos_1 = (position_x, position_y + 1)
                if pos_1 in self.sp_position:
                    self.sp_opponent.append(pos)
                    self.sp_opponent.append(pos_1)
                    self.sp_check_opponent.append(pos)
                    self.sp_check_opponent.append(pos_1)

                    for i in range(2):
                        self.del_space(direction, position_x, position_y, i)
                else:
                    self.ship_2()
            else:
                self.ship_2()

        for i in range(4):
            direction = random.randint(0, 1)
            if direction == 0:
                pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8]
                pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            else:
                pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8]
                pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            position_x = random.choice(pos_list_x)
            position_y = random.choice(pos_list_y)
            pos = (position_x, position_y)
            if pos in self.sp_position:
                self.sp_opponent.append(pos)
                self.sp_check_opponent.append(pos)

                self.del_space(direction, position_x, position_y, 0)

            else:
                self.ship_1()

    def del_space(self, direction, position_x, position_y, i):
        #проверка расстановки кораблей
        if direction == 0:
            pos = (position_x + i, position_y)
            pos_1 = (position_x + i - 1, position_y - 1)
            pos_2 = (position_x + i, position_y - 1)
            pos_3 = (position_x + i + 1, position_y - 1)
            pos_4 = (position_x + i + 1, position_y)
            pos_5 = (position_x + i + 1, position_y + 1)
            pos_6 = (position_x + i, position_y + 1)
            pos_7 = (position_x + i - 1, position_y + 1)
            pos_8 = (position_x + i - 1, position_y)
        else:
            pos = (position_x, position_y + i)
            pos_1 = (position_x - 1, position_y + i - 1)
            pos_2 = (position_x, position_y + i - 1)
            pos_3 = (position_x + 1, position_y + i - 1)
            pos_4 = (position_x + 1, position_y + i)
            pos_5 = (position_x + 1, position_y + i + 1)
            pos_6 = (position_x, position_y + 1 + i)
            pos_7 = (position_x - 1, position_y + i + 1)
            pos_8 = (position_x - 1, position_y + i)
        if pos in self.sp_position:
            self.sp_position.remove(pos)
        if pos_1 in self.sp_position:
            self.sp_position.remove(pos_1)
        if pos_2 in self.sp_position:
            self.sp_position.remove(pos_2)
        if pos_3 in self.sp_position:
            self.sp_position.remove(pos_3)
        if pos_4 in self.sp_position:
            self.sp_position.remove(pos_4)
        if pos_5 in self.sp_position:
            self.sp_position.remove(pos_5)
        if pos_6 in self.sp_position:
            self.sp_position.remove(pos_6)
        if pos_7 in self.sp_position:
            self.sp_position.remove(pos_7)
        if pos_8 in self.sp_position:
            self.sp_position.remove(pos_8)

    def ship_3(self):
        direction = random.randint(0, 1)
        if direction == 0:
            pos_list_x = [0, 1, 2, 3, 4, 5, 6]
            pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        else:
            pos_list_y = [0, 1, 2, 3, 4, 5, 6]
            pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        position_x = random.choice(pos_list_x)
        position_y = random.choice(pos_list_y)
        pos = (position_x, position_y)
        if pos in self.sp_position:
            if direction == 0:
                pos_1 = (position_x + 1, position_y)
            else:
                pos_1 = (position_x, position_y + 1)
            if pos_1 in self.sp_position:
                if direction == 0:
                    pos_2 = (position_x + 2, position_y)
                else:
                    pos_2 = (position_x, position_y + 2)
                if pos_2 in self.sp_position:
                    self.sp_opponent.append(pos)
                    self.sp_opponent.append(pos_1)
                    self.sp_opponent.append(pos_2)
                    self.sp_check_opponent.append(pos)
                    self.sp_check_opponent.append(pos_1)
                    self.sp_check_opponent.append(pos_2)
                    for i in range(3):
                        self.del_space(direction, position_x, position_y, i)
                else:
                    self.ship_3()
            else:
                self.ship_3()
        else:
            self.ship_3()

    def ship_2(self):
        direction = random.randint(0, 1)
        if direction == 0:
            pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7]
            pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        else:
            pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7]
            pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        position_x = random.choice(pos_list_x)
        position_y = random.choice(pos_list_y)
        pos = (position_x, position_y)
        if pos in self.sp_position:
            if direction == 0:
                pos_1 = (position_x + 1, position_y)
            else:
                pos_1 = (position_x, position_y + 1)
            if pos_1 in self.sp_position:
                self.sp_opponent.append(pos)
                self.sp_opponent.append(pos_1)
                self.sp_check_opponent.append(pos)
                self.sp_check_opponent.append(pos_1)

                for i in range(2):
                    self.del_space(direction, position_x, position_y, i)
            else:
                self.ship_2()
        else:
            self.ship_2()

    def ship_1(self):
        direction = random.randint(0, 1)
        if direction == 0:
            pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8]
            pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        else:
            pos_list_y = [0, 1, 2, 3, 4, 5, 6, 7, 8]
            pos_list_x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        position_x = random.choice(pos_list_x)
        position_y = random.choice(pos_list_y)
        pos = (position_x, position_y)
        if pos in self.sp_position:
            self.sp_opponent.append(pos)
            self.sp_check_opponent.append(pos)

            self.del_space(direction, position_x, position_y, 0)

        else:
            self.ship_1()


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Не удаётся загрузить:', name)
        raise SystemExit(message)
    # image = image.convert_alpha()
    # if color_key is not None:
    #    if color_key is -1:
    #       color_key = image.get_at((0, 0))
    #   image.set_colorkey(color_key)
    return image


def start_screen():
    intro_text = ["", "", "", "                                            Продвинутый Морской бой"]

    fon = pygame.transform.scale(load_image('fon.jpg'), size)
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)


def show_go_screen_0():
    intro_text = ["                                               Вы проиграли :(", "", ""
                  "Количество попадний:  " + str(
                      board.score) + "                   Количетсво попаданий противника:  " + str(
                      board.score_opponent),
                  "Количество промахов:  " + str(
                      board.no_score) + "                   Количество промахов противника:  " + str(
                      board.no_score_opponent),
                  "Процент попаданий:  " + str((board.score / (board.score + board.no_score) * 100))[0:2] + "%" +
                  "                   Процент попаданий противника:  " +
                  str((board.score_opponent / (board.score_opponent + board.no_score_opponent) * 100))[0:2] + "%"]
    fon = pygame.transform.scale(load_image('loss.jpg'), size)
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('Red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False


def show_go_screen_1():
    intro_text = ["                                               Вы выиграли! :)", "", ""
                  "Количество попадний:  " + str(
                      board.score) + "                   Количетсво попаданий противника:  " + str(
                      board.score_opponent),
                  "Количество промахов:  " + str(
                      board.no_score) + "                   Количество промахов противника:  " + str(
                      board.no_score_opponent),
                  "Процент попаданий:  " + str((board.score / (board.score + board.no_score) * 100))[0:2] + "%" +
                  "                   Процент попаданий противника:  " +
                  str((board.score_opponent / (board.score_opponent + board.no_score_opponent) * 100))[0:2] + "%"]
    fon = pygame.transform.scale(load_image('win.jpg'), size)
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('Black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False


if __name__ == '__main__':
    pygame.init()
    FPS = 50
    pygame.display.set_caption("Морской бой")
    size = 800, 400
    screen = pygame.display.set_mode(size)
    clock = pygame.time.Clock()
    start_screen()
    board = Board(10, 10)
    board.ship_arrangement()
    # game_over = board.board_game_over
    running = True
    while running:
        if board.board_game_over and board.board_result == 0:
            show_go_screen_0()
            running = False
        elif board.board_game_over and board.board_result == 1:
            show_go_screen_1()
            running = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                board.get_click(event.pos)

        screen.fill((240, 255, 240))
        board.render(screen)
        board.render2(screen)

        pygame.display.flip()

    pygame.quit()